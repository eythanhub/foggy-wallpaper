command: ""
refreshFrequency: false

style: """
  top: 0
  left: 0
  bottom: 0
  right: 0
  width: 100%
  height: 100%
  z-index: -1
  pointer-events: none
"""

render: (output) -> """
  <iframe
    src="foggy-wallpaper.widget/HUB_VoidSmoke_Wallpaper.html"
    style="border:none;width:100vw;height:100vh;position:fixed;top:0;left:0;"
    scrolling="no">
  </iframe>
"""
